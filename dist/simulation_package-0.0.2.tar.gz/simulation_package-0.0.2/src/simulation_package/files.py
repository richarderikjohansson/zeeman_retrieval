from pathlib import Path
from typing import List


def find_file(name: str) -> Path:
    """Find file

    Args:
        name: Name of file

    Returns:
        Path to file

    Raises:
        FileNotFoundError: Raise if file not is found.
    """
    parents = Path(__file__).parent

    for path in parents.rglob(name):
        if path.exists():
            return path
    raise FileNotFoundError(f"Can not find file: {name}")


def find_files() -> tuple[List[Path], List[Path]]:
    """Find paths to measurement and ycalc data

    Returns:
        List of file paths

    Raises:
        FileNotFoundError: Raise if measurement and/or simulation data cannot be found
    """
    meas = "Data*"
    sims = "YCALC_*"

    parents = Path.cwd().parent
    sims_paths = []
    meas_paths = []
    for path in parents.rglob(sims):
        sims_paths.append(path)

    for path in parents.rglob(meas):
        meas_paths.append(path)

    if len(meas_paths) == 0 or len(sims_paths) == 0:
        raise FileNotFoundError("Can not find paths to measurement and/or simulations")
    else:
        return meas_paths, sims_paths


def imgs_path():
    parents = Path(__file__).parents
    target = "data"
