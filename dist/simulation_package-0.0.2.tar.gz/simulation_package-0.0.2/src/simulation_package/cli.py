import argparse
from ret import ret
from ycalc import yc
from spec_plot import meas_plot, meas_sim_comparison
from pathlib import Path

COMMANDS = {"ycalc": yc, "retrieval": ret}
PLOTTING = {""}

DESC = {
    "ycalc": "Perform ycalc of 233.95 GHz O2 line at azi = [0, 90, 180, 270] and za = 77.6",
    "retrieval": "Perform synttich retrieval of 233.95 GHz O2 line",
}


def check_imgs_path():
    imgs = Path.cwd() / "imgs"
    if not imgs.exists():
        imgs.mkdir()


def cli():
    parser = argparse.ArgumentParser(add_help=True)
    subparsers = parser.add_subparsers(
        dest="command", required=True, description="Available commands"
    )

    for name in COMMANDS.keys():
        desc = DESC[name]
        subparser = subparsers.add_parser(name, help=desc, description=desc)
        subparser.add_argument(
            "--plotmeas",
            action="store_true",
            help="Plot measurement and ycalc"
        )

    args = parser.parse_args()
    script = COMMANDS[args.command]
    script()
    if args.plot:
        check_imgs_path()

    match args.command:
        case "ycalc":
            if args.plot:
                meas_plot()
                meas_sim_comparison()
        case "retrieval":
            if args.plot:
                pass


if __name__ == "__main__":
    cli()
