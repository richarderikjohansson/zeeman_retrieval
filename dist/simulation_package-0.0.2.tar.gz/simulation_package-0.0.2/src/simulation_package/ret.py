from simulation_package.retrieval import Retrieval


# run retrieval
def ret():
    kimra_zeeman = Retrieval(line="kimra", recalc=True, zeeman=True)
    kimra_zeeman.do_OEM(filename="retirieval_zeeman.hdf5")
