import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1.inset_locator import inset_axes, mark_inset
from .hdf import mm_scaler, get_bound, read_hdf5
from .files import find_file, find_files


def meas_plot():
    path = find_file(name="Data_2024-01-04_15-06-38_RPGFFTS.hdf5")
    measurement = read_hdf5(path)
    f0 = 233.9461e9  # linecenter
    s = 4635
    e = 5028

    # full spectrum plot
    freq = measurement["f"][20::]
    spec = measurement["y"][20::]
    s, e = get_bound(data=freq, f0=f0)

    xmin, xmax, ymin, ymax = freq[s] / 1e9, freq[e] / 1e9, 120, 134
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(freq / 1e9, spec, color="black")
    ax.tick_params(axis="both", labelsize=13)
    ax.set_xlabel(r"$\nu$ [GHz]", fontsize=16)
    ax.set_ylabel(r"$T_B$ [K]", fontsize=16)

    inset_ax = inset_axes(ax, width="30%", height="50%", loc="center")
    inset_ax.plot(freq / 1e9, spec, color="black")
    inset_ax.set_xlim(xmin, xmax)
    inset_ax.set_ylim(ymin, ymax)
    inset_ax.set_title(r"Zeeman affected transition of $^{16}O^{18}O$", fontsize=12)
    # Mark the zoomed area on the main plot
    inset_ax.set_xticks([])
    inset_ax.set_yticks([])
    inset_ax.tick_params(left=False, bottom=False)  # Hide tick marks
    # inset_ax.set_ticks_position('none')  # Remove tick lines

    mark_inset(ax, inset_ax, loc1=2, loc2=3, fc="none", ec="0.5")
    fig.savefig("imgs/fig02.pdf", transparent=True)


def meas_sim_comparison():
    measp, simp = find_files()
    meas = [read_hdf5(file) for file in sorted(measp)]
    sims = [read_hdf5(file) for file in sorted(simp)]
    hmap = {0: "0", 90: "90", 180: "180", -90: "270"}
    measurements = {}
    simulations = {}

    for m in meas:
        azimuth = m["azimuth"]
        measurements[hmap[azimuth]] = m

    for s in sims:
        azimuth = m["azimuth"]
        simulations[hmap[azimuth]] = s
